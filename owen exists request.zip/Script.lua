function onCreate()
STAGE = 'stage'

if STAGE == 'stage' then
		--put add sprite script here
		elseif STAGE == 'stage2' then
			--put add sprite script here
		end
	end
end

end



function onTimerCompleted(tag, loops, loopsLeft)
	if tag == '1' then
		--put remove sprite script here

		--put add sprite script here
	elseif tag == '2'
		--put remove sprite script here

		--put add sprite script here

	end
end
