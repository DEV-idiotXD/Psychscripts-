function onEvent(name, value1, value2)
	name == 'timer' then
	runTimer(value1, 0.001, 1)
end
